package Test;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.Loginpage_Objects;
import Pages.Logout_Objects;
import Pages.Orderpage_objects;

public class validateLogin {
	WebDriver driver;

	Loginpage_Objects LoginObj;
	Logout_Objects Logout_Obj;
	Orderpage_objects Order_Obj;

	@BeforeTest
	public void initialiseBrowser() {
		
		File file = new File("C:\\Users\\Admin\\Desktop\\chromedriver_win32 (1)\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver = new ChromeDriver();
		driver.get("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");
		
		LoginObj = new Loginpage_Objects(driver);
		Logout_Obj = new Logout_Objects(driver);
		Order_Obj = new Orderpage_objects(driver);
	}
	
	@Test
	public  void  login() throws InterruptedException {

		LoginObj.doLogin("Tester","test");
		Thread.sleep(6000);
		System.out.println("Loggedin successfully and navigated to the Landing page");
		
	} 
 
}
