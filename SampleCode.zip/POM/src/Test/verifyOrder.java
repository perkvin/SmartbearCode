package Test;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Pages.Loginpage_Objects;
import Pages.Logout_Objects;
import Pages.Orderpage_objects;

public class verifyOrder extends validateLogin {
	WebDriver driver;

	@BeforeTest
	public void initialiseBrowser() {
		File file = new File("C:\\Users\\Admin\\Desktop\\chromedriver_win32 (1)\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
		driver = new ChromeDriver();
		driver.get("http://secure.smartbearsoftware.com/samples/testcomplete11/WebOrders/login.aspx");
		LoginObj = new Loginpage_Objects(driver);
		Logout_Obj = new Logout_Objects(driver);
		Order_Obj = new Orderpage_objects(driver);
		
	}

	@Test
	public void Order_Creation() throws InterruptedException {

		driver.findElement(By.xpath("//*[@id=\'ctl00_menu\']/li[3]/a")).click();
		Thread.sleep(3000);
		Order_Obj.enter_Quantity("3");
		Order_Obj.enter_Customername("Vinoth");
		Order_Obj.enter_Streetname("RK Salai");
		Order_Obj.enter_CIty("Chennai");
		Order_Obj.enter_Zipcode("603101");
		Order_Obj.enter_CardType();
		Order_Obj.enter_CardNumber("123456789012");
		Order_Obj.enter_Code("02/07");
		Order_Obj.Order_Submit();
		System.out.println("SUccessully Created Orders in the Order Cart Page");

	}
	@AfterTest
	public void CloseBrowser() {
		
		driver.close();
	}
}
