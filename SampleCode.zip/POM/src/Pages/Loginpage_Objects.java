package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Loginpage_Objects {
	WebDriver driver;
 

	@FindBy(xpath="//*[@id=\"ctl00_MainContent_username\"]")
	WebElement username;
		
	@FindBy(xpath="//*[@id=\"ctl00_MainContent_password\"]")
	WebElement password;
	
	@FindBy(xpath="//*[@id=\"ctl00_MainContent_login_button\"]")
	WebElement submit;
	
	//Constructor
	public Loginpage_Objects(WebDriver drive) {
		driver = drive;
		PageFactory.initElements(driver, this);
	}

	public void doLogin(String userdata, String passworddata) {
	
		enter_Username(userdata);
		enter_Password(passworddata);
		Submit();
	}

	public void enter_Username(String usernamedata) {
		username.sendKeys(usernamedata);
	}

	public void enter_Password(String passwordData) {
		password.sendKeys(passwordData);
	}

	public void Submit() {
		submit.sendKeys(Keys.ENTER);
	}

}