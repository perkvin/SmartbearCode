package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Logout_Objects {
	WebDriver driver;


	By orderTxt = By.xpath("//*[@id='ctl00_menu']/li[3]/a");

	public Logout_Objects(WebDriver drive) {
		// TODO Auto-generated constructor stub
		driver = drive;
		PageFactory.initElements(driver, this);
	}

	public boolean Validate_Login() {

		if(driver.findElements(orderTxt).size()!=0){

			return true;
		}
		else {
			return false;
		}
	}

}
