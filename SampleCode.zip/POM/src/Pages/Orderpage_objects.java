package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Orderpage_objects {
	WebDriver driver;



	/*By Quantity = By.xpath("//*[@id=\"ctl00_MainContent_fmwOrder_txtQuantity\"]");
	By Customername = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_txtName\']");
	By Streetname = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_TextBox2\']");
	By City = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_TextBox3\']");
	By Zipcode = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_TextBox5\']");
	By CardType = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_cardList_1\']");
	By CardNumber = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_TextBox6\']");
	By Code = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_TextBox1\']");
	By Order_Submit = By.xpath("//*[@id=\'ctl00_MainContent_fmwOrder_InsertButton\']");*/

	
	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_txtQuantity\']")
	WebElement quantity;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_txtName\']")
	WebElement customer_name;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_TextBox2\']")
	WebElement street_Name;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_TextBox3\']")
	WebElement city;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_TextBox5\']")
	WebElement zipcode;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_cardList_1\']")
	WebElement card_type;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_TextBox6\']")
	WebElement card_Number;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_TextBox1\']")
	WebElement secretcode;

	@FindBy(xpath="//*[@id=\'ctl00_MainContent_fmwOrder_InsertButton\']")
	WebElement ordersubmit;

	public Orderpage_objects(WebDriver drive) {
		// TODO Auto-generated constructor stub
		driver = drive;
		PageFactory.initElements(driver, this);
	}

	public void enter_Quantity(String QuantityData) {
		quantity.sendKeys(QuantityData);

	}

	public void enter_Customername(String customernameData) {
		customer_name.sendKeys(customernameData);

	}

	public void enter_Streetname(String StreetnameData) {
		street_Name.sendKeys(StreetnameData);

	}

	public void enter_CIty(String CitynameData) {
		city.sendKeys(CitynameData);
	}

	public void enter_Zipcode(String ZipcodeData) {
		zipcode.sendKeys(ZipcodeData);
	}

	public void enter_CardType() {
		card_type.click();
	}

	public void enter_CardNumber(String CardNumberData) {
		//driver.findElement(CardNumber).sendKeys(CardNumberData);
		card_Number.sendKeys(CardNumberData);
	}

	public void enter_Code(String CodeData) {
		//driver.findElement(CodeData).sendKeys(CodeData);
		secretcode.sendKeys(CodeData);
	}


	public void Order_Submit() {
		//driver.findElement(Order_Submit).click();
		ordersubmit.click();

	}



}
